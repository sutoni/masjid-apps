<?php
$name='Siddhanta';
$type='TTF';
$desc=array (
  'Ascent' => 1236,
  'Descent' => -582,
  'CapHeight' => 729,
  'Flags' => 4,
  'FontBBox' => '[-745 -673 1470 1236]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 0,
);
$up=-82;
$ut=55;
$ttffile='C:/xampp/htdocs/MPDF56/ttfonts/siddhanta.ttf';
$TTCfontID='0';
$originalsize=1168564;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='siddhanta';
$panose=' 0 0 2 0 5 0 2 0 0 2 0 2';
$haskerninfo=false;
$unAGlyphs=false;
?>